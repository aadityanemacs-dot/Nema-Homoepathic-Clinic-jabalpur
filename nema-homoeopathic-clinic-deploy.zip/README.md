# Nema Homoeopathic Clinic (नेमा होम्योपैथिक क्लीनिक)
**Official Website for Dr. Pankaj Nema — Jabalpur, Madhya Pradesh**

A modern, fast, mobile-first, and fully responsive static website built for **Nema Homoeopathic Clinic** (Brand: *Dr. Nema's Homoeopathic Clinic*). Designed for patient clarity, high accessibility (elderly-friendly), bilingual fluency (English + Hindi), and zero-friction deployment to **Netlify** or **Vercel** with a 100/100 Lighthouse performance target.

---

## 🌟 Key Features

1. **Bilingual Toggle (EN / हिं)**:
   - Instant switching between English and Hindi with memory state (`localStorage`).
   - Styled with clean Google Fonts (`Poppins`/`Inter` and `Noto Sans Devanagari`).

2. **Single Config / Data File (`assets/js/clinic-data.js`)**:
   - Every piece of clinical content, doctor credentials, phone numbers, address, timings, holiday warnings, 11 medical condition categories, reviews, and gallery items is isolated in one easy-to-edit file.

3. **Dynamic Real-Time Clinic Timing Engine**:
   - Automatically computes whether the clinic is currently **Open** or **Closed** based on the two shifts (11:00 AM – 2:00 PM and 6:00 PM – 9:00 PM, Sunday closed).
   - Highlights the current day in the schedule table.

4. **Direct WhatsApp Appointment Booking**:
   - Interactive appointment form that constructs an encoded message with patient name, phone, preferred slot, and health concern, opening directly to Dr. Pankaj Nema's WhatsApp (+91 75664 52940) without needing any database or backend server.

5. **10 Comprehensive Page Sections**:
   - **Hero**: Trust chips, doctor credentials (B.H.M.S., MDems, DECE, DAFE, Reg. 20284), CTAs.
   - **About Doctor**: Dr. Pankaj Nema's bio, holistic patient-listening philosophy, and experience counter.
   - **Services / Conditions Treated**: 11 categories with Lucide SVG line icons and category filters.
   - **Why Homoeopathy**: 5 key principles (side-effect free, treats whole person, builds immunity).
   - **How a Visit Works**: 3 clear steps for patients.
   - **Patient Reviews**: Real themes based on Google reviews ("patient listening", "understanding doctor", "friendly atmosphere").
   - **Clinic Gallery**: Real clinic entrance, interior consultation area, and health awareness posters with an interactive lightbox modal.
   - **Timings & Location**: Embedded Google Map, "Get Directions" button, and landmark guide.
   - **Appointment Form**: Direct WhatsApp booking form.
   - **Footer**: Memorial tribute line (*"In loving memory of Shri Kanhedi Lal Nema Ji"*), registration number, phone numbers, and ethical medical disclaimer.

6. **SEO & Accessibility**:
   - Semantic HTML5, ARIA labels, image alt tags, high contrast ratio.
   - Open Graph, Twitter Cards, Meta tags, and **Schema.org LocalBusiness + Physician JSON-LD structured data**.

---

## 📁 File Structure

```
nema-homoeopathic-clinic/
├── index.html                   # Main single-page application
├── robots.txt                   # Search crawler directives
├── sitemap.xml                  # XML sitemap for Google indexing
├── netlify.toml                 # Netlify 1-click deployment configuration
├── vercel.json                  # Vercel 1-click deployment configuration
├── README.md                    # Documentation & maintenance guide
└── assets/
    ├── css/
    │   └── styles.css           # Modern medical stylesheet (Tailwind-like system)
    ├── js/
    │   ├── clinic-data.js       # SINGLE CONFIG FILE for all content & translations
    │   └── main.js              # Application logic, i18n, timing engine, lightbox
    └── images/
        ├── doctor.jpg           # Portrait of Dr. Pankaj Nema
        ├── clinic-front.jpg     # Clinic front with signboard
        ├── clinic-inside.jpg    # Clinic interior consultation counter
        └── posters/             # Clinical awareness guides
            ├── joint-pain-treatment.jpg
            ├── womens-wellness.jpg
            ├── skin-care-treatment.jpg
            ├── autism-child-health.jpg
            ├── kidney-care.jpg
            ├── thyroid-care.jpg
            ├── fertility-care.jpg
            ├── family-physician.jpg
            └── clinic-pamphlet.jpg
```

---

## 🚀 How to Run Locally

Because this site is built with modern, standard HTML5/CSS3/ES6+, **no build step or compiler is required**:

### Option 1: Directly in your browser
Simply double-click `index.html` or drag it into Chrome, Edge, Safari, or Firefox.

### Option 2: Using VS Code Live Server
1. Open the `nema-homoeopathic-clinic` folder in VS Code.
2. Right-click `index.html` and click **"Open with Live Server"**.

### Option 3: Using Python HTTP server (if Python is installed)
Run the following in the terminal inside this directory:
```bash
python -m http.server 3000
```
Then visit `http://localhost:3000`.

---

## 🌐 How to Deploy for Free

### Deploying to Netlify (Fastest - under 1 minute)
1. Visit [Netlify](https://www.netlify.com/) and log in (free account).
2. Go to the **Sites** tab.
3. Drag and drop the `nema-homoeopathic-clinic` folder directly into the browser window.
4. Your website is instantly live with a free SSL certificate!
5. *(Optional)* Link your custom domain (e.g. `nemahomoeopathy.com`).

### Deploying to Vercel
1. Push this folder to a GitHub repository.
2. Go to [Vercel](https://vercel.com/) and click **"Add New Project"**.
3. Select your repository. Vercel will automatically detect `vercel.json` and deploy it instantly as a high-speed static website.

---

## ✏️ How to Edit Content & Replace Images

### 1. Editing Clinic Details, Phone Numbers, or Timings
Open `assets/js/clinic-data.js`:
- To change phone numbers: update `primaryPhone`, `secondaryPhone`, or `whatsappNumber`.
- To edit timings: update the `timings` array in `meta.timings`.
- To update Doctor's bio: edit `meta.doctor.bio.en` or `meta.doctor.bio.hi`.
- To add or modify conditions treated: edit the `services` array.
- To update Google reviews: edit the `reviews` array.

### 2. Replacing Images
Simply replace the image files in `assets/images/`:
- `assets/images/doctor.jpg` → Doctor's photo (recommended square or 3:4 aspect ratio).
- `assets/images/clinic-front.jpg` → Exterior clinic photo showing signboard.
- `assets/images/clinic-inside.jpg` → Reception or interior view.
- `assets/images/posters/` → Any treatment poster or infographic.

---

## 📞 Clinic Contact Reference
- **Doctor**: Dr. Pankaj Nema (B.H.M.S., MDems, DECE, DAFE)
- **Registration**: 20284
- **Primary Phone**: +91 75664 52940
- **Secondary Phone**: +91 88784 52940
- **WhatsApp**: [https://wa.me/917566452940](https://wa.me/917566452940)
- **Address**: D-2, SBI Chowk, Vijay Nagar Road, near Hanuman Temple, behind Krishi Upaj Mandi, Vijay Nagar, Jabalpur, Madhya Pradesh 482002
- **Google Maps**: [https://maps.app.goo.gl/Rukh1R9qHGQPebGK8](https://maps.app.goo.gl/Rukh1R9qHGQPebGK8)
