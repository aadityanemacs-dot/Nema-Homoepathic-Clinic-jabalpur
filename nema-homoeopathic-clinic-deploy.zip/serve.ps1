# PowerShell Lightweight Static Web Server
param(
    [int]$Port = 8080,
    [string]$Root = "C:\Users\aadit\.gemini\antigravity\scratch\nema-homoeopathic-clinic"
)

$mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".htm"  = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".gif"  = "image/gif"
    ".svg"  = "image/svg+xml"
    ".ico"  = "image/x-icon"
    ".mp4"  = "video/mp4"
    ".webm" = "video/webm"
    ".txt"  = "text/plain; charset=utf-8"
    ".xml"  = "application/xml; charset=utf-8"
}

$ip = [System.Net.IPAddress]::Loopback
$listener = New-Object System.Net.Sockets.TcpListener($ip, $Port)
$listener.Start()
Write-Host "Server running at http://localhost:$Port/" -ForegroundColor Green
Write-Host "Serving files from: $Root"

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $reader = New-Object System.IO.StreamReader($stream)
            $requestLine = $reader.ReadLine()

            if ($requestLine) {
                $tokens = $requestLine.Split(" ")
                if ($tokens.Length -ge 2 -and $tokens[0] -eq "GET") {
                    $rawUrl = $tokens[1]
                    # Strip query string or hash
                    $cleanUrl = $rawUrl.Split("?")[0].Split("#")[0]
                    if ($cleanUrl -eq "/" -or $cleanUrl -eq "") {
                        $cleanUrl = "/index.html"
                    }

                    $cleanUrl = $cleanUrl.TrimStart("/").Replace("/", "\")
                    $filePath = [System.IO.Path]::Combine($Root, $cleanUrl)

                    if ([System.IO.File]::Exists($filePath)) {
                        $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
                        $contentType = if ($mimeTypes.ContainsKey($ext)) { $mimeTypes[$ext] } else { "application/octet-stream" }
                        $bytes = [System.IO.File]::ReadAllBytes($filePath)

                        $header = "HTTP/1.1 200 OK`r`n" +
                                  "Content-Type: $contentType`r`n" +
                                  "Content-Length: $($bytes.Length)`r`n" +
                                  "Access-Control-Allow-Origin: *`r`n" +
                                  "Connection: close`r`n`r`n"
                        $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
                        $stream.Write($headerBytes, 0, $headerBytes.Length)
                        $stream.Write($bytes, 0, $bytes.Length)
                    } else {
                        $msg = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
                        $header = "HTTP/1.1 404 Not Found`r`nContent-Type: text/plain`r`nContent-Length: $($msg.Length)`r`nConnection: close`r`n`r`n"
                        $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
                        $stream.Write($headerBytes, 0, $headerBytes.Length)
                        $stream.Write($msg, 0, $msg.Length)
                    }
                }
            }
            $stream.Flush()
            $stream.Close()
        } catch {
            # Client disconnected or connection aborted gracefully
        } finally {
            if ($client) {
                $client.Close()
            }
        }
    }
} finally {
    $listener.Stop()
}
