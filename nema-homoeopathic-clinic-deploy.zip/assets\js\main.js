/**
 * Nema Homoeopathic Clinic - Main Application Script
 * High performance, zero dependency, accessible vanilla JavaScript
 */

(function () {
  'use strict';

  // State
  const urlParams = (typeof window !== 'undefined' && window.location.search) ? new URLSearchParams(window.location.search) : null;
  const langQuery = urlParams ? urlParams.get('lang') : null;
  let currentLang = (langQuery === 'hi' || langQuery === 'en') ? langQuery : (localStorage.getItem('nema_clinic_lang') || 'en');
  let activeServiceFilter = 'all';
  let activeGalleryTab = 'all';

  // SVG Icons library (lucide-style paths)
  const ICONS = {
    sparkles: '<svg class="icon icon-lg" viewBox="0 0 24 24"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>',
    activity: '<svg class="icon icon-lg" viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>',
    shield: '<svg class="icon icon-lg" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    heart: '<svg class="icon icon-lg" viewBox="0 0 24 24"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
    smile: '<svg class="icon icon-lg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" x2="9.01" y1="9" y2="9"/><line x1="15" x2="15.01" y1="9" y2="9"/></svg>',
    target: '<svg class="icon icon-lg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
    wind: '<svg class="icon icon-lg" viewBox="0 0 24 24"><path d="M17.7 7.7A2.5 2.5 0 1 1 20 12H2"/><path d="M19.7 17.7A2.5 2.5 0 1 1 18 20H2"/><path d="M12 4.5A2.5 2.5 0 0 0 9.5 2H2"/></svg>',
    'volume-2': '<svg class="icon icon-lg" viewBox="0 0 24 24"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>',
    droplet: '<svg class="icon icon-lg" viewBox="0 0 24 24"><path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/></svg>',
    moon: '<svg class="icon icon-lg" viewBox="0 0 24 24"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>',
    'plus-circle': '<svg class="icon icon-lg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="16"/><line x1="8" x2="16" y1="12" y2="12"/></svg>',
    leaf: '<svg class="icon icon-lg" viewBox="0 0 24 24"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/></svg>',
    users: '<svg class="icon icon-lg" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    compass: '<svg class="icon icon-lg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>',
    'shield-check': '<svg class="icon icon-lg" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>',
    zap: '<svg class="icon icon-lg" viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
    info: '<svg class="icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="16" y2="12"/><line x1="12" x2="12.01" y1="8" y2="8"/></svg>',
    check: '<svg class="icon" viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
    phone: '<svg class="icon" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
    clock: '<svg class="icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
    mapPin: '<svg class="icon" viewBox="0 0 24 24"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>'
  };

  /**
   * DOM Ready Initializer
   */
  document.addEventListener('DOMContentLoaded', () => {
    initLanguage();
    renderStaticContent();
    renderServices(activeServiceFilter);
    renderWhyHomoeopathy();
    renderReviews();
    renderGallery(activeGalleryTab);
    renderVideos();
    renderTimingsTable();
    updateLiveTimingStatus();
    initAppointmentForm();
    initMobileNav();
    initLightbox();
    initFiltersAndTabs();
    initGlowAndScrollSpy();

    // Recheck live timing every 60 seconds
    setInterval(updateLiveTimingStatus, 60000);

    // Handle deep-link anchor scroll after dynamic components render
    if (window.location.hash) {
      setTimeout(() => {
        try {
          const target = document.querySelector(window.location.hash);
          if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        } catch (e) {}
      }, 200);
    }
  });

  /**
   * Initialize Language and Event Handlers
   */
  function initLanguage() {
    const langEnBtn = document.getElementById('lang-en-btn');
    const langHiBtn = document.getElementById('lang-hi-btn');

    if (langEnBtn && langHiBtn) {
      langEnBtn.addEventListener('click', () => switchLanguage('en'));
      langHiBtn.addEventListener('click', () => switchLanguage('hi'));
    }

    applyLanguage(currentLang);
  }

  function switchLanguage(lang) {
    if (currentLang === lang) return;
    currentLang = lang;
    localStorage.setItem('nema_clinic_lang', lang);
    applyLanguage(lang);
  }

  function applyLanguage(lang) {
    document.documentElement.lang = lang;
    document.body.classList.toggle('lang-hi', lang === 'hi');

    // Update Toggle Pills
    const pillEn = document.getElementById('lang-en-btn');
    const pillHi = document.getElementById('lang-hi-btn');
    if (pillEn && pillHi) {
      pillEn.classList.toggle('active', lang === 'en');
      pillHi.classList.toggle('active', lang === 'hi');
    }

    // Update document title
    const t = CLINIC_DATA.translations[lang];
    document.title = t.siteTitle;

    // Update elements with data-i18n
    const translatableElements = document.querySelectorAll('[data-i18n]');
    translatableElements.forEach((el) => {
      const key = el.getAttribute('data-i18n');
      if (t[key]) {
        el.textContent = t[key];
      }
    });

    // Update elements with placeholder translations
    const placeholderElements = document.querySelectorAll('[data-i18n-placeholder]');
    placeholderElements.forEach((el) => {
      const key = el.getAttribute('data-i18n-placeholder');
      if (t[key]) {
        el.setAttribute('placeholder', t[key]);
      }
    });

    // Update Doctor and Clinic Info
    renderDoctorBio(lang);
    renderAddressAndMemorial(lang);

    // Re-render Dynamic Sections
    renderServices(activeServiceFilter);
    renderWhyHomoeopathy();
    renderReviews();
    renderGallery(activeGalleryTab);
    renderVideos();
    renderTimingsTable();
    updateLiveTimingStatus();
  }

  /**
   * Render Static Doctor Bio and Memorial
   */
  function renderDoctorBio(lang) {
    const docBioEl = document.getElementById('doctor-bio-text');
    if (docBioEl) {
      docBioEl.textContent = CLINIC_DATA.meta.doctor.bio[lang];
    }
    const docTitleEl = document.getElementById('doctor-title-text');
    if (docTitleEl) {
      docTitleEl.textContent = CLINIC_DATA.meta.doctor.title[lang];
    }
  }

  function renderAddressAndMemorial(lang) {
    const tributeEl = document.getElementById('footer-memorial-text');
    if (tributeEl) {
      tributeEl.textContent = CLINIC_DATA.meta.tributeLine[lang];
    }
    const addressEls = document.querySelectorAll('.clinic-address-text');
    addressEls.forEach((el) => {
      el.textContent = CLINIC_DATA.meta.address[lang];
    });
    const holidayEl = document.getElementById('holiday-note-text');
    if (holidayEl) {
      holidayEl.textContent = CLINIC_DATA.meta.holidayNote[lang];
    }
  }

  function renderStaticContent() {
    // Populate raw phone numbers and links
    const phonePrimaryLinks = document.querySelectorAll('.phone-primary-link');
    phonePrimaryLinks.forEach((el) => {
      el.setAttribute('href', `tel:+${CLINIC_DATA.meta.primaryPhoneRaw}`);
      if (el.classList.contains('show-number')) {
        el.textContent = CLINIC_DATA.meta.primaryPhone;
      }
    });

    const phoneSecondaryLinks = document.querySelectorAll('.phone-secondary-link');
    phoneSecondaryLinks.forEach((el) => {
      el.setAttribute('href', `tel:+${CLINIC_DATA.meta.secondaryPhoneRaw}`);
      if (el.classList.contains('show-number')) {
        el.textContent = CLINIC_DATA.meta.secondaryPhone;
      }
    });

    const whatsappLinks = document.querySelectorAll('.whatsapp-link');
    whatsappLinks.forEach((el) => {
      el.setAttribute('href', CLINIC_DATA.meta.whatsappUrl);
    });

    const mapLinks = document.querySelectorAll('.google-maps-link');
    mapLinks.forEach((el) => {
      el.setAttribute('href', CLINIC_DATA.meta.googleMapsUrl);
    });
  }

  /**
   * Render Services Cards
   */
  function renderServices(filter) {
    const container = document.getElementById('services-grid-container');
    if (!container) return;

    const filteredServices = CLINIC_DATA.services.filter((svc) => {
      if (filter === 'all') return true;
      return svc.category === filter;
    });

    container.innerHTML = filteredServices
      .map((svc) => {
        const title = svc.title[currentLang];
        const tagline = svc.tagline[currentLang];
        const conditions = svc.conditions[currentLang];
        const note = svc.note[currentLang];
        const iconSvg = ICONS[svc.icon] || ICONS['plus-circle'];

        const conditionsHtml = conditions
          .map((cond) => `<span class="condition-badge">${cond}</span>`)
          .join('');

        return `
          <article class="service-card" data-category="${svc.category}">
            <div class="service-header">
              <div class="service-icon-box" aria-hidden="true">${iconSvg}</div>
              <h3 class="service-title">${title}</h3>
            </div>
            <p class="service-tagline">${tagline}</p>
            <div class="service-conditions-list">
              ${conditionsHtml}
            </div>
            <div class="service-note">
              ${ICONS.info}
              <span>${note}</span>
            </div>
          </article>
        `;
      })
      .join('');
  }

  /**
   * Render Why Homoeopathy Section
   */
  function renderWhyHomoeopathy() {
    const container = document.getElementById('why-grid-container');
    if (!container) return;

    container.innerHTML = CLINIC_DATA.whyHomoeopathy
      .map((item) => {
        const title = item.title[currentLang];
        const desc = item.desc[currentLang];
        const iconSvg = ICONS[item.icon] || ICONS['leaf'];

        return `
          <div class="why-card">
            <div class="why-icon-box" aria-hidden="true">${iconSvg}</div>
            <h3 class="why-card-title">${title}</h3>
            <p class="why-card-desc">${desc}</p>
          </div>
        `;
      })
      .join('');
  }

  /**
   * Render Patient Reviews Section
   */
  function renderReviews() {
    const container = document.getElementById('reviews-grid-container');
    if (!container) return;

    container.innerHTML = CLINIC_DATA.reviews
      .map((rev) => {
        const name = rev.name[currentLang];
        const location = rev.location[currentLang];
        const quote = rev.quote[currentLang];
        const theme = rev.themeTag[currentLang];

        const stars = Array(rev.rating)
          .fill('★')
          .join('');

        return `
          <div class="review-card">
            <div>
              <div class="review-stars" aria-label="${rev.rating} out of 5 stars">${stars}</div>
              <p class="review-quote">${quote}</p>
            </div>
            <div class="review-meta">
              <div class="review-author">
                <span class="review-name">${name}</span>
                <span class="review-location">${location}</span>
              </div>
              <span class="review-tag">${theme}</span>
            </div>
          </div>
        `;
      })
      .join('');
  }

  /**
   * Render Gallery Section
   */
  function renderGallery(tab) {
    const container = document.getElementById('gallery-grid-container');
    if (!container) return;

    const filteredGallery = CLINIC_DATA.gallery.filter((item) => {
      if (tab === 'all') return true;
      if (tab === 'photos') return item.type === 'photo';
      if (tab === 'posters') return item.type === 'poster';
      return true;
    });

    container.innerHTML = filteredGallery
      .map((item, index) => {
        const title = item.title[currentLang];
        const subtitle = item.subtitle[currentLang];
        const isPoster = item.type === 'poster';

        return `
          <div class="gallery-item ${isPoster ? 'is-poster' : ''}" data-index="${index}" data-src="${item.src}" data-title="${title}" data-subtitle="${subtitle}">
            <div class="gallery-image-box">
              <img src="${item.src}" alt="${title}" class="gallery-img" loading="lazy" />
            </div>
            <div class="gallery-overlay">
              <h4 class="gallery-title">${title}</h4>
              <p class="gallery-subtitle">${subtitle}</p>
            </div>
          </div>
        `;
      })
      .join('');

    // Attach lightbox click listeners
    const galleryItems = container.querySelectorAll('.gallery-item');
    galleryItems.forEach((el) => {
      el.addEventListener('click', () => {
        const src = el.getAttribute('data-src');
        const title = el.getAttribute('data-title');
        const subtitle = el.getAttribute('data-subtitle');
        openLightbox(src, title, subtitle);
      });
    });
  }

  /**
   * Render Video Tour Section
   */
  function renderVideos() {
    const container = document.getElementById('videos-grid-container');
    if (!container || !CLINIC_DATA.videos) return;

    // Check if any video is playing to prevent interrupting playback during language switch
    const videos = container.querySelectorAll('video');
    let hasPlayingVideo = false;
    videos.forEach((vid) => {
      if (!vid.paused && !vid.ended && vid.currentTime > 0) {
        hasPlayingVideo = true;
      }
    });

    if (hasPlayingVideo) {
      const cards = container.querySelectorAll('.video-card');
      CLINIC_DATA.videos.forEach((v, idx) => {
        const card = cards[idx];
        if (!card) return;
        const tagEl = card.querySelector('.video-tag');
        const titleEl = card.querySelector('.video-card-title');
        const descEl = card.querySelector('.video-card-desc');
        if (tagEl && v.tag) tagEl.textContent = currentLang === 'hi' ? v.tag.hi : v.tag.en;
        if (titleEl && v.title) titleEl.textContent = currentLang === 'hi' ? v.title.hi : v.title.en;
        if (descEl && v.description) descEl.textContent = currentLang === 'hi' ? v.description.hi : v.description.en;
      });
      return;
    }

    container.innerHTML = CLINIC_DATA.videos
      .map((v) => {
        const tag = v.tag ? (currentLang === 'hi' ? v.tag.hi : v.tag.en) : '';
        const title = currentLang === 'hi' ? v.title.hi : v.title.en;
        const desc = currentLang === 'hi' ? v.description.hi : v.description.en;

        return `
          <article class="video-card">
            <div class="video-wrapper">
              <video 
                class="video-element" 
                controls 
                preload="metadata" 
                poster="${v.poster}" 
                playsinline
                aria-label="${title}">
                <source src="${v.src}" type="video/mp4">
                Your browser does not support HTML5 video.
              </video>
              <div class="video-duration-badge">
                <svg class="icon" viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                <span>${v.duration}</span>
              </div>
            </div>
            <div class="video-card-body">
              ${tag ? `<span class="video-tag">${tag}</span>` : ''}
              <h3 class="video-card-title">${title}</h3>
              <p class="video-card-desc">${desc}</p>
            </div>
          </article>
        `;
      })
      .join('');
  }

  /**
   * Render Timings Table
   */
  function renderTimingsTable() {
    const tbody = document.getElementById('timings-table-body');
    if (!tbody) return;

    const currentDay = new Date().getDay(); // 0 is Sunday, 1 is Monday...

    tbody.innerHTML = CLINIC_DATA.meta.timings
      .map((t) => {
        const isToday = t.dayIndex === currentDay;
        const dayName = currentLang === 'hi' ? t.nameHi : t.nameEn;
        const shift1 = t.isOpen ? t.shift1 : (currentLang === 'hi' ? 'अवकाश (बंद)' : 'Closed');
        const shift2 = t.isOpen ? t.shift2 : (currentLang === 'hi' ? 'अवकाश (बंद)' : 'Closed');

        return `
          <tr class="${isToday ? 'today-highlight' : ''}">
            <td><strong>${dayName}</strong></td>
            <td>${shift1}</td>
            <td>${shift2}</td>
          </tr>
        `;
      })
      .join('');
  }

  /**
   * Real-Time Open / Closed Status Engine
   */
  function updateLiveTimingStatus() {
    const now = new Date();
    const day = now.getDay(); // 0: Sun, 1: Mon, ... 6: Sat
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const totalMinutes = hours * 60 + minutes;

    // Clinic Shifts in minutes from midnight:
    // Shift 1: 11:00 AM (660m) - 2:00 PM (840m)
    // Shift 2: 6:00 PM (1080m) - 9:00 PM (1260m)
    const shift1Start = 11 * 60; // 660
    const shift1End = 14 * 60;   // 840
    const shift2Start = 18 * 60; // 1080
    const shift2End = 21 * 60;   // 1260

    let isOpen = false;
    let statusText = '';
    let badgeClass = 'status-closed';

    if (day === 0) {
      // Sunday: Closed
      isOpen = false;
      statusText = currentLang === 'hi'
        ? 'रविवार अवकाश • सोमवार सुबह 11:00 बजे खुलेगा'
        : 'Closed Today (Sunday) • Opens Mon at 11:00 AM';
    } else {
      // Monday to Saturday
      if (totalMinutes >= shift1Start && totalMinutes < shift1End) {
        isOpen = true;
        badgeClass = 'status-open';
        statusText = currentLang === 'hi'
          ? 'अभी खुला है • दोपहर 2:00 बजे तक'
          : 'Open Now • Closes at 2:00 PM';
      } else if (totalMinutes >= shift2Start && totalMinutes < shift2End) {
        isOpen = true;
        badgeClass = 'status-open';
        statusText = currentLang === 'hi'
          ? 'अभी खुला है • रात्रि 9:00 बजे तक'
          : 'Open Now • Closes at 9:00 PM';
      } else if (totalMinutes < shift1Start) {
        isOpen = false;
        statusText = currentLang === 'hi'
          ? 'अभी बंद है • आज सुबह 11:00 बजे खुलेगा'
          : 'Closed Now • Opens today at 11:00 AM';
      } else if (totalMinutes >= shift1End && totalMinutes < shift2Start) {
        isOpen = false;
        statusText = currentLang === 'hi'
          ? 'दोपहर ब्रेक • आज शाम 6:00 बजे खुलेगा'
          : 'Afternoon Break • Reopens today at 6:00 PM';
      } else {
        isOpen = false;
        const nextDayText = day === 6
          ? (currentLang === 'hi' ? 'सोमवार सुबह 11:00 बजे' : 'Mon at 11:00 AM')
          : (currentLang === 'hi' ? 'कल सुबह 11:00 बजे' : 'tomorrow at 11:00 AM');
        statusText = currentLang === 'hi'
          ? `आज का समय समाप्त • ${nextDayText} खुलेगा`
          : `Closed for today • Opens ${nextDayText}`;
      }
    }

    // Update Hero badge
    const heroStatusDot = document.getElementById('hero-status-dot');
    const heroStatusText = document.getElementById('hero-status-text');
    if (heroStatusText) {
      heroStatusText.textContent = statusText;
    }
    if (heroStatusDot) {
      heroStatusDot.style.backgroundColor = isOpen ? '#22c55e' : '#ef4444';
      heroStatusDot.style.boxShadow = isOpen ? '0 0 0 3px rgba(34, 197, 94, 0.35)' : '0 0 0 3px rgba(239, 68, 68, 0.35)';
    }

    // Update Timings section live badge
    const liveBadgeContainer = document.getElementById('live-timing-badge');
    if (liveBadgeContainer) {
      liveBadgeContainer.className = `live-status-badge ${badgeClass}`;
      liveBadgeContainer.innerHTML = `
        <span class="status-dot" style="background-color: ${isOpen ? '#22c55e' : '#ef4444'}"></span>
        <span>${statusText}</span>
      `;
    }
  }

  /**
   * Appointment Form Handling
   */
  function initAppointmentForm() {
    const form = document.getElementById('appointment-form');
    if (!form) return;

    // Set default date to today or tomorrow
    const dateInput = document.getElementById('form-date');
    if (dateInput) {
      const today = new Date().toISOString().split('T')[0];
      dateInput.min = today;
      dateInput.value = today;
    }

    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = document.getElementById('form-name').value.trim();
      const phone = document.getElementById('form-phone').value.trim();
      const date = document.getElementById('form-date').value;
      const slot = document.getElementById('form-slot').value;
      const problem = document.getElementById('form-problem').value.trim();

      if (!name || !phone) {
        alert(currentLang === 'hi' ? 'कृपया अपना नाम और मोबाइल नंबर भरें।' : 'Please enter your name and phone number.');
        return;
      }

      // Generate WhatsApp message
      const message = 
`*Appointment Request - Nema Homoeopathic Clinic*
---------------------------------------
*Patient Name:* ${name}
*Contact Number:* ${phone}
*Preferred Date:* ${date}
*Preferred Slot:* ${slot}
*Health Concern / Problem:* ${problem || 'Consultation'}

Please confirm slot availability. Thank you!`;

      const encodedMessage = encodeURIComponent(message);
      const whatsappUrl = `https://wa.me/${CLINIC_DATA.meta.whatsappNumber}?text=${encodedMessage}`;

      // Open WhatsApp in new tab
      window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    });
  }

  /**
   * Filter and Tab Listeners
   */
  function initFiltersAndTabs() {
    // Services Category Filter
    const filterPills = document.querySelectorAll('.filter-pill');
    filterPills.forEach((pill) => {
      pill.addEventListener('click', () => {
        filterPills.forEach((p) => p.classList.remove('active'));
        pill.classList.add('active');
        activeServiceFilter = pill.getAttribute('data-filter') || 'all';
        renderServices(activeServiceFilter);
      });
    });

    // Gallery Tabs
    const galleryTabs = document.querySelectorAll('.gallery-tab-btn');
    galleryTabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        galleryTabs.forEach((t) => t.classList.remove('active'));
        tab.classList.add('active');
        activeGalleryTab = tab.getAttribute('data-gallery-tab') || 'all';
        renderGallery(activeGalleryTab);
      });
    });
  }

  /**
   * Lightbox Modal
   */
  let lightboxModal = null;
  let lightboxImg = null;
  let lightboxTitle = null;
  let lightboxSubtitle = null;

  function initLightbox() {
    lightboxModal = document.getElementById('lightbox-modal');
    lightboxImg = document.getElementById('lightbox-img');
    lightboxTitle = document.getElementById('lightbox-title');
    lightboxSubtitle = document.getElementById('lightbox-subtitle');
    const closeBtn = document.getElementById('lightbox-close-btn');

    if (!lightboxModal) return;

    if (closeBtn) {
      closeBtn.addEventListener('click', closeLightbox);
    }

    lightboxModal.addEventListener('click', (e) => {
      if (e.target === lightboxModal) {
        closeLightbox();
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && lightboxModal.classList.contains('active')) {
        closeLightbox();
      }
    });
  }

  function openLightbox(src, title, subtitle) {
    if (!lightboxModal) return;
    lightboxImg.src = src;
    lightboxTitle.textContent = title;
    lightboxSubtitle.textContent = subtitle;
    lightboxModal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    if (!lightboxModal) return;
    lightboxModal.classList.remove('active');
    document.body.style.overflow = '';
  }

  /**
   * Mobile Navigation Menu
   */
  function initMobileNav() {
    const toggleBtn = document.getElementById('mobile-nav-toggle-btn');
    const drawer = document.getElementById('mobile-drawer');
    const navLinks = document.querySelectorAll('.mobile-nav-link');

    if (!toggleBtn || !drawer) return;

    toggleBtn.addEventListener('click', () => {
      drawer.classList.toggle('open');
      const isOpen = drawer.classList.contains('open');
      toggleBtn.setAttribute('aria-expanded', isOpen);
    });

    navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        drawer.classList.remove('open');
        toggleBtn.setAttribute('aria-expanded', false);
      });
    });
  }

  /**
   * Interactive Glowing Click Effect & Active Navigation Tracker
   */
  function initGlowAndScrollSpy() {
    const interactiveElements = document.querySelectorAll('.nav-link, .btn, .lang-toggle-pill, .filter-pill');
    interactiveElements.forEach((el) => {
      el.addEventListener('pointerdown', function () {
        this.classList.add('active-click');
      });
      el.addEventListener('pointerup', function () {
        setTimeout(() => this.classList.remove('active-click'), 450);
      });
      el.addEventListener('mouseleave', function () {
        this.classList.remove('active-click');
      });
    });

    // Smooth Scroll Spy for Navigation Active State
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');

    window.addEventListener('scroll', () => {
      let currentSectionId = '';
      const scrollPos = window.scrollY + 120;

      sections.forEach((sec) => {
        const top = sec.offsetTop;
        const height = sec.offsetHeight;
        if (scrollPos >= top && scrollPos < top + height) {
          currentSectionId = sec.getAttribute('id');
        }
      });

      if (currentSectionId) {
        navLinks.forEach((link) => {
          const href = link.getAttribute('href');
          if (href === '#' + currentSectionId) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    }, { passive: true });
  }

})();
