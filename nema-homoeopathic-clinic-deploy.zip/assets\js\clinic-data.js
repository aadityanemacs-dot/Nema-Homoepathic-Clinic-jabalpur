/**
 * Nema Homoeopathic Clinic - Central Data Configuration
 * Edit this file to update doctor details, contact numbers, timings, services, reviews, and translations.
 */

const CLINIC_DATA = {
  meta: {
    regNo: "20284",
    establishedYear: "2010",
    experienceYears: "15+",
    primaryPhone: "+91 75664 52940",
    primaryPhoneRaw: "917566452940",
    secondaryPhone: "+91 88784 52940",
    secondaryPhoneRaw: "918878452940",
    whatsappNumber: "917566452940",
    whatsappUrl: "https://wa.me/917566452940",
    googleMapsUrl: "https://maps.app.goo.gl/Rukh1R9qHGQPebGK8",
    googleMapsEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3667.6256214582697!2d79.90048687588325!3d23.18386121030064!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3981b11b51684c31%3A0x7d0e4a77e5e3170e!2sNema%20Homoeopathic%20Clinic.%20Dr.%20Pankaj%20Nema.%20Best%20homoeopathic%20clinic!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin",
    address: {
      en: "D-2, SBI Chowk, Vijay Nagar Road, near Hanuman Temple, behind Krishi Upaj Mandi, Vijay Nagar, Jabalpur, Madhya Pradesh 482002",
      hi: "डी-2, एसबीआई चौक, विजय नगर रोड, श्री हनुमान मंदिर के पास, कृषि उपज मंडी के पीछे, विजय नगर, जबलपुर, मध्य प्रदेश 482002"
    },
    tributeLine: {
      en: "In loving memory of Shri Kanhedi Lal Nema Ji",
      hi: "श्री कन्हेदी लाल नेमा जी की स्मृति में"
    },
    doctor: {
      name: {
        en: "Dr. Pankaj Nema",
        hi: "डॉ. पंकज नेमा"
      },
      degrees: "B.H.M.S., MDems, DECE, DAFE",
      title: {
        en: "Senior Homoeopathic Physician & Family Consultant",
        hi: "वरिष्ठ होम्योपैथिक चिकित्सक एवं फैमिली कंसल्टेंट"
      },
      image: "assets/images/doctor.jpg",
      bio: {
        en: "Dr. Pankaj Nema is a dedicated homoeopathic physician with over 15 years of clinical experience in treating acute and long-standing chronic ailments. Practicing with deep compassion and classical homoeopathic principles, Dr. Nema believes in listening patiently to every individual's case history to find the constitutional root cause, delivering safe, non-invasive, and holistic healing for patients of all ages.",
        hi: "डॉ. पंकज नेमा एक अनुभवी और समर्पित होम्योपैथिक चिकित्सक हैं, जिन्हें गंभीर एवं पुराने रोगों के सफल उपचार में 15 से अधिक वर्षों का अनुभव है। डॉ. नेमा प्रत्येक रोगी की समस्या को अत्यंत धैर्यपूर्वक सुनकर उनकी व्यक्तिगत शारीरिक व मानसिक प्रकृति के अनुरूप मूल कारण का उपचार करने में विश्वास रखते हैं।"
      }
    },
    timings: [
      { dayIndex: 1, nameEn: "Monday", nameHi: "सोमवार", shift1: "11:00 AM – 2:00 PM", shift2: "6:00 PM – 9:00 PM", isOpen: true },
      { dayIndex: 2, nameEn: "Tuesday", nameHi: "मंगलवार", shift1: "11:00 AM – 2:00 PM", shift2: "6:00 PM – 9:00 PM", isOpen: true },
      { dayIndex: 3, nameEn: "Wednesday", nameHi: "बुधवार", shift1: "11:00 AM – 2:00 PM", shift2: "6:00 PM – 9:00 PM", isOpen: true },
      { dayIndex: 4, nameEn: "Thursday", nameHi: "गुरुवार", shift1: "11:00 AM – 2:00 PM", shift2: "6:00 PM – 9:00 PM", isOpen: true },
      { dayIndex: 5, nameEn: "Friday", nameHi: "शुक्रवार", shift1: "11:00 AM – 2:00 PM", shift2: "6:00 PM – 9:00 PM", isOpen: true },
      { dayIndex: 6, nameEn: "Saturday", nameHi: "शनिवार", shift1: "11:00 AM – 2:00 PM", shift2: "6:00 PM – 9:00 PM", isOpen: true },
      { dayIndex: 0, nameEn: "Sunday", nameHi: "रविवार", shift1: "Closed", shift2: "Closed", isOpen: false }
    ],
    holidayNote: {
      en: "Timings may differ on public holidays. Please call to confirm before visiting.",
      hi: "त्योहारों एवं सार्वजनिक अवकाशों पर समय में परिवर्तन हो सकता है। कृपया आने से पहले फोन करके पुष्टि कर लें।"
    }
  },

  translations: {
    en: {
      siteTitle: "Nema Homoeopathic Clinic | Dr. Pankaj Nema | Vijay Nagar, Jabalpur",
      clinicBrand: "Nema Homoeopathic Clinic",
      clinicBrandVariant: "Dr. Nema's Homoeopathic Clinic",
      navHome: "Home",
      navAbout: "About",
      navServices: "Services",
      navWhy: "Why Homoeopathy",
      navProcess: "How It Works",
      navReviews: "Reviews",
      navGallery: "Gallery",
      navTimings: "Timings",
      navContact: "Contact Us",
      callNow: "Call Now",
      bookAppointment: "Book Appointment",
      bookOnlineConsultation: "Online Consultation",
      getDirections: "Get Directions",
      emergencyNotice: "For acute medical emergencies, please reach out to the nearest emergency medical facility immediately.",
      
      // Hero
      heroTagline: "Protect your family naturally with Homoeopathy",
      heroHeadline: "Natural, Safe Homoeopathic Care for Your Whole Family",
      heroDescription: "Experience compassionate, holistic healthcare by Dr. Pankaj Nema at Vijay Nagar, Jabalpur. Gentle constitutional treatment focused on deep healing, root-cause resolution, and lasting wellness.",
      chipReg: "Reg. No. 20284",
      chipOnline: "Online Consultation Available",
      chipTimings: "Mon – Sat Open (2 Shifts)",
      chipFamily: "All Age Groups Welcome",

      // About
      aboutSubtitle: "Dedicated to Patient-Centric Healing",
      aboutTitle: "Meet Dr. Pankaj Nema",
      aboutExperienceLabel: "Years of Clinical Practice",
      aboutPatientsLabel: "Happy Families Served",
      aboutRegLabel: "State Homoeopathic Council Reg.",
      aboutPhilosophyTitle: "Philosophy of Holistic Healing",
      aboutPhilosophyText: "At Nema Homoeopathic Clinic, every consultation is guided by the core classical homoeopathic axiom: treat the patient, not just the disease. We dedicate ample time to listen to your full health history, environmental triggers, mental stress, and constitution. Our aim is to stimulate your body's innate natural self-healing powers without harsh side effects.",
      aboutFeature1Title: "In-Depth Case Analysis",
      aboutFeature1Desc: "Comprehensive 20-30 minute patient consultation focusing on emotional, physical, and constitutional factors.",
      aboutFeature2Title: "Safe For All Ages",
      aboutFeature2Desc: "Non-invasive sweet pills and liquid potencies gentle enough for newborns, pregnant mothers, and seniors.",
      aboutFeature3Title: "In-Clinic & Online Care",
      aboutFeature3Desc: "Consult in person at Vijay Nagar, Jabalpur, or connect via WhatsApp audio/video consultation from home.",

      // Services
      servicesSubtitle: "Comprehensive Care",
      servicesTitle: "Specialised Conditions Treated & Managed",
      servicesIntro: "Homoeopathy offers safe, individualised supportive care and chronic disease management. Explore the health conditions we address:",
      servicesDisclaimer: "Disclaimer: Homoeopathy is offered as complementary and constitutional care. Patients are advised to continue necessary conventional treatment as recommended by their primary physicians.",
      filterAll: "All Conditions",
      filterSkin: "Skin & Hair",
      filterWomen: "Women's Health",
      filterChild: "Child Care",
      filterJoint: "Joints & Pain",
      filterChronic: "Chronic & Lifestyle",

      // Why Homoeopathy
      whySubtitle: "Natural Healing Philosophy",
      whyTitle: "Why Choose Homoeopathy?",
      whyIntro: "Homoeopathy is a time-tested, gentle medical system based on individualised natural remedies that stimulate the body's self-healing mechanisms.",

      // How it works
      howSubtitle: "Simple 3-Step Process",
      howTitle: "How Your Consultation Works",
      howStep1Num: "01",
      howStep1Title: "Connect via Call or WhatsApp",
      howStep1Desc: "Book your preferred morning or evening consultation slot or request an online video/audio appointment with Dr. Nema.",
      howStep2Num: "02",
      howStep2Title: "Detailed Case Taking",
      howStep2Desc: "A peaceful, attentive discussion where Dr. Nema listens to your symptoms, medical history, diet, and lifestyle.",
      howStep3Num: "03",
      howStep3Title: "Personalised Treatment Plan",
      howStep3Desc: "Receive customised, pure homoeopathic remedies along with supportive dietary advice and scheduled progress reviews.",

      // Reviews
      reviewsSubtitle: "Patient Experiences",
      reviewsTitle: "What Patients Say",
      reviewsIntro: "Real themes reflected in patient feedback from Google reviews and clinic visits in Jabalpur.",
      viewOnGoogle: "See All Reviews on Google",
      verifiedPatient: "Patient Review (Verified Theme)",

      // Gallery
      gallerySubtitle: "Our Clinic & Facilities",
      galleryTitle: "Clinic Gallery & Awareness",
      galleryIntro: "Take a look at our clean, welcoming clinic at SBI Chowk, Vijay Nagar, Jabalpur.",
      tabPhotos: "Clinic Photos",
      tabPosters: "Health Awareness Guides",

      // Video Tour
      navVideos: "Videos",
      videoSubtitle: "Live Clinic Tour & Consultation",
      videoTitle: "Clinic Video Tour & Glimpses",
      videoIntro: "Authentic video glimpses of Dr. Pankaj Nema in patient consultation, the clinic signboard at night, and dispensary facilities in Jabalpur.",
      videoPlayHint: "Click to play with sound",
      videoDurationLabel: "Duration",

      // Timings & Location
      timingsSubtitle: "Visit Our Clinic",
      timingsTitle: "Timings & Directions",
      timingsToday: "Today's Schedule",
      shiftMorning: "Morning Shift",
      shiftEvening: "Evening Shift",
      closedSunday: "Sunday Closed (Available on Emergency Call/WhatsApp)",
      locationHeading: "Clinic Location & Address",
      openNow: "Open Now",
      closedNow: "Closed Now",
      statusCheck: "Checking Hours...",
      landmarkLabel: "Landmarks:",
      landmarkText: "Near Shri Hanuman Temple, Behind Krishi Upaj Mandi, SBI Chowk",

      // Appointment Form
      formSubtitle: "Quick & Direct Booking",
      formTitle: "Book an Appointment",
      formIntro: "Fill in your details below to instantly connect with Dr. Pankaj Nema via WhatsApp. No login required.",
      formNameLabel: "Patient Full Name",
      formNamePlaceholder: "e.g. Ramesh Kumar",
      formPhoneLabel: "Mobile Number",
      formPhonePlaceholder: "e.g. 98765 43210",
      formDateLabel: "Preferred Date",
      formSlotLabel: "Preferred Time Shift",
      slotMorning: "Morning Shift (11:00 AM – 2:00 PM)",
      slotEvening: "Evening Shift (6:00 PM – 9:00 PM)",
      slotOnline: "Online Video/Phone Consultation",
      formProblemLabel: "Health Concern / Problem in Brief",
      formProblemPlaceholder: "Briefly describe your symptoms (e.g., skin rash, joint pain, acidity, recurring cough...)",
      formSubmitBtn: "Confirm & Send via WhatsApp",
      formSecureNote: "Your health details are directly sent to Dr. Nema's clinic WhatsApp and kept strictly confidential.",

      // Footer
      footerTagline: "Protect your family naturally with gentle, constitutional homoeopathy.",
      footerQuickLinks: "Quick Links",
      footerContactTitle: "Clinic Details",
      footerLegalTitle: "Medical Disclaimer",
      footerDisclaimer: "Information provided on this website is for educational and general health awareness only and does not constitute formal medical diagnosis or advice. Outcomes may vary between individuals based on constitution. Homoeopathy works in harmony with medical sciences. In an emergency, kindly rush to the nearest tertiary hospital.",
      footerCopyright: "Nema Homoeopathic Clinic. All rights reserved.",
      designedFor: "Crafted with care for patient wellness in Jabalpur, MP."
    },

    hi: {
      siteTitle: "नेमा होम्योपैथिक क्लीनिक | डॉ. पंकज नेमा | विजय नगर, जबलपुर",
      clinicBrand: "नेमा होम्योपैथिक क्लीनिक",
      clinicBrandVariant: "डॉ. नेमा होम्योपैथिक क्लीनिक",
      navHome: "होम",
      navAbout: "डॉक्टर",
      navServices: "उपचार",
      navWhy: "होम्योपैथी क्यों?",
      navProcess: "प्रक्रिया",
      navReviews: "समीक्षाएं",
      navGallery: "गैलरी",
      navTimings: "समय व पता",
      navContact: "संपर्क करें",
      callNow: "कॉल करें",
      bookAppointment: "अपॉइंटमेंट लें",
      bookOnlineConsultation: "ऑनलाइन परामर्श",
      getDirections: "रास्ता देखें",
      emergencyNotice: "आपातकालीन स्थिति में कृपया तुरंत अपने नजदीकी अस्पताल में संपर्क करें।",

      // Hero
      heroTagline: "सभी उम्र के लिए प्राकृतिक और सुरक्षित इलाज",
      heroHeadline: "आपके पूरे परिवार के लिए प्राकृतिक और सुरक्षित होम्योपैथिक उपचार",
      heroDescription: "जबलपुर के विजय नगर में डॉ. पंकज नेमा द्वारा संपूर्ण व धैर्यपूर्ण स्वास्थ्य परामर्श। बिना किसी दुष्प्रभाव के रोग के मूल कारण का जड़ से समाधान।",
      chipReg: "पंजीकरण क्र. 20284",
      chipOnline: "ऑनलाइन परामर्श उपलब्ध",
      chipTimings: "सोम – शनि खुला (दो शिफ्ट)",
      chipFamily: "बच्चों से लेकर बुजुर्गों तक",

      // About
      aboutSubtitle: "मरीज की संतुष्टि ही हमारा ध्येय",
      aboutTitle: "डॉ. पंकज नेमा (B.H.M.S., MDems) से मिलें",
      aboutExperienceLabel: "वर्षों का सफल अनुभव",
      aboutPatientsLabel: "संतुष्ट परिवार",
      aboutRegLabel: "राज्य होम्योपैथिक परिषद पंजीयन",
      aboutPhilosophyTitle: "समग्र उपचार का सिद्धांत",
      aboutPhilosophyText: "नेमा होम्योपैथिक क्लीनिक में हमारा मुख्य उद्देश्य केवल रोग के लक्षणों को दबाना नहीं, बल्कि पूरे व्यक्ति का उसके शारीरिक व मानसिक लक्षणों के आधार पर स्थायी उपचार करना है। डॉ. पंकज नेमा हर मरीज की बात को पूरी तसल्ली से सुनते हैं और शुद्ध, हानिरहित होम्योपैथिक औषधियां प्रदान करते हैं।",
      aboutFeature1Title: "विस्तृत केस हिस्ट्री",
      aboutFeature1Desc: "प्रत्येक मरीज के साथ 20-30 मिनट का व्यक्तिगत परामर्श, ताकि रोग की जड़ को समझा जा सके।",
      aboutFeature2Title: "सभी उम्र के लिए हानिरहित",
      aboutFeature2Desc: "मीठी गोलियां और बूंदें जो बच्चों, गर्भवती महिलाओं और बुजुर्गों के लिए पूरी तरह सुरक्षित हैं।",
      aboutFeature3Title: "क्लीनिक एवं ऑनलाइन सुविधा",
      aboutFeature3Desc: "विजय नगर क्लीनिक पर प्रत्यक्ष आएं या घर बैठे फोन/व्हाट्सएप द्वारा ऑनलाइन परामर्श प्राप्त करें।",

      // Services
      servicesSubtitle: "व्यापक स्वास्थ्य सेवाएं",
      servicesTitle: "प्रमुख रोग एवं उपलब्ध उपचार सुविधाएं",
      servicesIntro: "होम्योपैथी पुरानी और जटिल बीमारियों में अत्यंत कारगर और सुरक्षित है। नीचे दी गई समस्याओं के उपचार हेतु परामर्श लें:",
      servicesDisclaimer: "अस्वीकरण: होम्योपैथी पूरक एवं सुरक्षित चिकित्सा के रूप में दी जाती है। किसी गंभीर बीमारी में अपने मुख्य चिकित्सक की सलाह व दवा भी जारी रखें।",
      filterAll: "सभी रोग",
      filterSkin: "त्वचा व बाल",
      filterWomen: "महिला स्वास्थ्य",
      filterChild: "शिशु रोग",
      filterJoint: "जोड़ व दर्द",
      filterChronic: "पुरानी बीमारियां",

      // Why Homoeopathy
      whySubtitle: "प्राकृतिक चिकित्सा की शक्ति",
      whyTitle: "होम्योपैथी ही क्यों चुनें?",
      whyIntro: "होम्योपैथी चिकित्सा प्रणाली बिना किसी नुकसान के शरीर की रोग प्रतिरोधक क्षमता को बढ़ाकर रोगों को जड़ से दूर करती है।",

      // How it works
      howSubtitle: "आसान 3 चरण",
      howTitle: "क्लीनिक परामर्श की प्रक्रिया",
      howStep1Num: "01",
      howStep1Title: "कॉल या व्हाट्सएप द्वारा संपर्क",
      howStep1Desc: "सुबह या शाम की अपनी सुविधानुसार समय स्लॉट बुक करें या ऑनलाइन कंसल्टेंसी के लिए मैसेज करें।",
      howStep2Num: "02",
      howStep2Title: "धैर्यपूर्वक विस्तृत परामर्श",
      howStep2Desc: "डॉ. नेमा आपकी हर बात, खान-पान, जीवनशैली और बीमारी के इतिहास को ध्यानपूर्वक सुनते हैं।",
      howStep3Num: "03",
      howStep3Title: "व्यक्तिगत औषधि व मार्गदर्शन",
      howStep3Desc: "रोग की स्थिति के अनुसार उच्च गुणवत्ता की होम्योपैथिक दवाइयां, खान-पान की सलाह और फॉलो-अप दिया जाता है।",

      // Reviews
      reviewsSubtitle: "मरीजों के अनुभव",
      reviewsTitle: "हमारे मरीजों की राय",
      reviewsIntro: "गूगल रिव्यूज एवं क्लीनिक में आने वाले परिवारों से प्राप्त वास्तविक फीडबैक के प्रमुख बिंदु।",
      viewOnGoogle: "गूगल पर सभी रिव्यू देखें",
      verifiedPatient: "मरीज का फीडबैक (सत्यापित)",

      // Gallery
      gallerySubtitle: "हमारा क्लीनिक",
      galleryTitle: "क्लीनिक परिसर एवं स्वास्थ्य जानकारी",
      galleryIntro: "एसबीआई चौक, विजय नगर, जबलपुर स्थित हमारे स्वच्छ व शांत क्लीनिक की एक झलक।",
      tabPhotos: "क्लीनिक की तस्वीरें",
      tabPosters: "रोग जागरूकता पोस्टर",

      // Video Tour
      navVideos: "वीडियो",
      videoSubtitle: "क्लीनिक वीडियो व टूर",
      videoTitle: "क्लीनिक वीडियो व परामर्श झलकियां",
      videoIntro: "एसबीआई चौक, विजय नगर, जबलपुर स्थित क्लीनिक में डॉ. पंकज नेमा द्वारा मरीज जांच व परामर्श की वास्तविक झलकियां।",
      videoPlayHint: "वीडियो चलाने के लिए क्लिक करें",
      videoDurationLabel: "अवधि",

      // Timings & Location
      timingsSubtitle: "क्लीनिक विजिट",
      timingsTitle: "समय एवं स्थान",
      timingsToday: "आज का समय",
      shiftMorning: "सुबह की शिफ्ट",
      shiftEvening: "शाम की शिफ्ट",
      closedSunday: "रविवार अवकाश (आपातकाल में फोन/व्हाट्सएप उपलब्ध)",
      locationHeading: "क्लीनिक का पूरा पता",
      openNow: "अभी खुला है",
      closedNow: "अभी बंद है",
      statusCheck: "समय की जांच हो रही है...",
      landmarkLabel: "पहचान स्थल:",
      landmarkText: "श्री हनुमान मंदिर के पास, कृषि उपज मंडी के पीछे, एसबीआई चौक",

      // Appointment Form
      formSubtitle: "आसान व सीधा संपर्क",
      formTitle: "अपॉइंटमेंट के लिए फॉर्म भरें",
      formIntro: "अपनी जानकारी भरें और एक क्लिक में सीधे डॉ. पंकज नेमा के व्हाट्सएप पर संदेश भेजें।",
      formNameLabel: "मरीज का पूरा नाम",
      formNamePlaceholder: "उदा. रमेश कुमार",
      formPhoneLabel: "मोबाइल नंबर",
      formPhonePlaceholder: "उदा. 98765 43210",
      formDateLabel: "पसंदीदा तारीख",
      formSlotLabel: "परामर्श का समय",
      slotMorning: "सुबह की शिफ्ट (11:00 पूर्वाह्न – 2:00 दोपहर)",
      slotEvening: "शाम की शिफ्ट (6:00 शाम – 9:00 रात्रि)",
      slotOnline: "ऑनलाइन फोन/वीडियो परामर्श",
      formProblemLabel: "समस्या का संक्षिप्त विवरण",
      formProblemPlaceholder: "अपनी परेशानी संक्षेप में बताएं (उदा. त्वचा रोग, जोड़ों का दर्द, गैस/एसिडिटी, खांसी...)",
      formSubmitBtn: "व्हाट्सएप पर अपॉइंटमेंट भेजें",
      formSecureNote: "आपकी स्वास्थ्य जानकारी सीधे डॉक्टर साहब के फोन पर सुरक्षित रूप से प्रेषित होगी।",

      // Footer
      footerTagline: "प्राकृतिक और सुरक्षित होम्योपैथी से अपने परिवार के स्वास्थ्य की रक्षा करें।",
      footerQuickLinks: "त्वरित लिंक",
      footerContactTitle: "संपर्क विवरण",
      footerLegalTitle: "चिकित्सीय अस्वीकरण",
      footerDisclaimer: "इस वेबसाइट पर दी गई जानकारी केवल सामान्य स्वास्थ्य जागरूकता हेतु है और यह किसी चिकित्सक के प्रत्यक्ष परामर्श का विकल्प नहीं है। प्रत्येक व्यक्ति की शारीरिक प्रकृति अनुसार परिणाम अलग हो सकते हैं। किसी भी आपात स्थिति में नजदीकी अस्पताल में संपर्क करें।",
      footerCopyright: "नेमा होम्योपैथिक क्लीनिक। सर्वाधिकार सुरक्षित।",
      designedFor: "जबलपुर वासियों के उत्तम स्वास्थ्य को समर्पित।"
    }
  },

  services: [
    {
      id: "skin-hair",
      category: "skin",
      icon: "sparkles",
      title: {
        en: "Skin & Hair Conditions",
        hi: "त्वचा एवं बालों के रोग"
      },
      tagline: {
        en: "Deep-acting, gentle remedies without harsh creams or steroids",
        hi: "बिना किसी स्टेरॉयड या साइड इफेक्ट के प्राकृतिक उपचार"
      },
      conditions: {
        en: ["Acne & Pimples", "Psoriasis", "Eczema", "Warts & Corns", "Pigmentation & Scars", "Severe Hair Fall & Alopecia", "Fungal Infections"],
        hi: ["मुंहासे (Acne & Pimples)", "सोरायसिस (Psoriasis)", "एक्जिमा (Eczema)", "मस्से (Warts)", "झाइयां व कालेपन के दाग", "बालों का झड़ना व गंजापन", "दाद-खाज व खुजली"]
      },
      note: {
        en: "Constitutional treatment to purify from within rather than suppressing surface symptoms.",
        hi: "लक्षणों को दबाने के बजाय अंदरूनी प्रतिरोधक क्षमता को ठीक करने पर जोर।"
      }
    },
    {
      id: "gastric-liver",
      category: "chronic",
      icon: "activity",
      title: {
        en: "Gastric, Digestive & Liver Care",
        hi: "पेट, पाचन एवं लिवर संबंधी समस्याएं"
      },
      tagline: {
        en: "Restoring gut balance, healthy metabolism, and digestive comfort",
        hi: "पाचन तंत्र को दुरुस्त कर गैस, कब्ज व एसिडिटी से स्थायी राहत"
      },
      conditions: {
        en: ["Chronic Acidity & GERD", "Habitual Constipation", "Irritable Bowel Syndrome (IBS)", "Piles (Haemorrhoids) & Fissures", "Fatty Liver & Jaundice", "Indigestion & Loss of Appetite"],
        hi: ["पुरानी एसिडिटी व खट्टी डकारें", "कब्जियत (Constipation)", "आई.बी.एस. (IBS)", "बवासीर (Piles) व फिशर", "फैटी लिवर (Fatty Liver)", "भूख न लगना व पेट फूलना"]
      },
      note: {
        en: "Holistic digestive support without dependency on frequent laxatives or antacids.",
        hi: "लंबे समय से एंटासिड या चूर्ण पर निर्भरता को कम करने में सहायक।"
      }
    },
    {
      id: "joint-bone-nerve",
      category: "joint",
      icon: "shield",
      title: {
        en: "Joint, Bone & Nerve Health",
        hi: "जोड़, हड्डी, कमर एवं नसों का दर्द"
      },
      tagline: {
        en: "Pain management and joint mobility support for active living",
        hi: "बिना पेनकिलर के दुष्प्रभाव के जोड़ों के दर्द व अकड़न से राहत"
      },
      conditions: {
        en: ["Knee Osteoarthritis", "Rheumatoid Arthritis", "Sciatica & Nerve Compression", "Cervical Spondylitis", "Chronic Lower Backache", "Frozen Shoulder & Gout"],
        hi: ["घुटनों का दर्द (Osteoarthritis)", "गठिया बाई (Rheumatoid Arthritis)", "साइटिका (Sciatica - नसों का खिंचाव)", "सर्वाइकल स्पॉन्डिलाइटिस", "कमर व रीढ़ का दर्द", "कंधे की जकड़न (Frozen Shoulder)"]
      },
      note: {
        en: "Reduces chronic inflammation and stiffness while nourishing joint cartilage and nerves.",
        hi: "सूजन कम करने तथा जोड़ों के लचीलेपन को पुनः लौटाने में अत्यंत उपयोगी।"
      }
    },
    {
      id: "women-wellness",
      category: "women",
      icon: "heart",
      title: {
        en: "Women's Wellness & Hormonal Balance",
        hi: "महिला स्वास्थ्य एवं हार्मोनल संतुलन"
      },
      tagline: {
        en: "Safe, natural support for women across all stages of life",
        hi: "महिलाओं की सभी अवस्थाओं के लिए सुरक्षित व प्राकृतिक चिकित्सा"
      },
      conditions: {
        en: ["PCOD / PCOS", "Irregular or Painful Periods", "Leucorrhoea (White Discharge)", "Uterine Fibroids Management", "Infertility Support & Consultation", "Thyroid Imbalances", "Menopausal Mood & Hot Flashes"],
        hi: ["पीसीओडी / पीसीओएस (PCOD/PCOS)", "माहवारी की अनियमितता व दर्द", "श्वेत प्रदर (Leucorrhoea)", "गर्भाशय में गांठ (Fibroids)", "निःसंतानता हेतु परामर्श व इलाज", "थायराइड असंतुलन", "मेनोपॉज की समस्याएं"]
      },
      note: {
        en: "Gentle hormonal balancing remedies without synthetic hormones or painful procedures.",
        hi: "बिना किसी चीरा या दर्द के प्राकृतिक रूप से हार्मोन्स को संतुलित करना।"
      }
    },
    {
      id: "child-health",
      category: "child",
      icon: "smile",
      title: {
        en: "Child Health & Developmental Support",
        hi: "शिशु स्वास्थ्य एवं बाल विकास परामर्श"
      },
      tagline: {
        en: "Gentle sweet pills that kids love, strengthening natural immunity",
        hi: "बच्चों के लिए मीठी दवाइयां जो इम्युनिटी बढ़ाकर बार-बार बीमार होने से बचाएं"
      },
      conditions: {
        en: ["Recurrent Cold, Cough & Fever", "Weak Immunity & Poor Growth", "Tonsillitis & Adenoids", "Developmental Concerns", "Autism Spectrum Supportive Care", "Hyperactivity & Concentration Difficulties", "Dentition Problems"],
        hi: ["बार-बार सर्दी, खांसी व बुखार", "कमजोर इम्युनिटी व भूख की कमी", "टॉन्सिल (Tonsillitis)", "धीमा विकास व बोलने में देरी", "ऑटिज़्म स्पेक्ट्रम सहायक परामर्श", "हाइपरएक्टिविटी व ध्यान की कमी", "दांत निकलते समय की परेशानियां"]
      },
      note: {
        en: "Autism support is offered as complementary behavioural and constitutional management. Always consult your multidisciplinary developmental team.",
        hi: "ऑटिज्म व व्यवहार संबंधी दिक्कतों में सहायक परामर्श उपलब्ध है। बाल विकास विशेषज्ञों के साथ मिलकर कार्य किया जाता है।"
      }
    },
    {
      id: "lifestyle-disorders",
      category: "chronic",
      icon: "target",
      title: {
        en: "Lifestyle & Metabolic Disorders",
        hi: "जीवनशैली एवं मेटाबॉलिक विकार"
      },
      tagline: {
        en: "Comprehensive management for modern lifestyle imbalances",
        hi: "आधुनिक दिनचर्या से उत्पन्न बीमारियों का संतुलित व सुरक्षित प्रबंधन"
      },
      conditions: {
        en: ["Hypothyroidism & Hyperthyroidism", "High Blood Pressure (Hypertension Support)", "Metabolic Imbalances & Diabetes Support", "Weight Management & Obesity Support", "Chronic Fatigue & General Debility"],
        hi: ["हाइपो एवं हाइपर थायराइड", "उच्च रक्तचाप (बीपी) सहायक देखभाल", "मधुमेह (शुगर) सहायक प्रबंधन", "मोटापा व मेटाबॉलिज्म असंतुलन", "पुरानी थकान व शारीरिक कमजोरी"]
      },
      note: {
        en: "Supportive homoeopathy works to optimize metabolic functioning alongside your healthy diet and doctor-advised medicine.",
        hi: "उचित आहार व व्यायाम के साथ मेटाबॉलिज्म को सुचारु बनाने में सहायक।"
      }
    },
    {
      id: "allergy-respiratory",
      category: "chronic",
      icon: "wind",
      title: {
        en: "Allergy & Respiratory Care",
        hi: "एलर्जी एवं श्वसन संबंधी रोग"
      },
      tagline: {
        en: "Calming hyper-sensitive airways and stopping recurring seasonal attacks",
        hi: "मौसम बदलने पर होने वाले जुकाम, छींकों और दमा से मुक्ति"
      },
      conditions: {
        en: ["Allergic Rhinitis & Frequent Sneezing", "Asthma & Wheezing Breathlessness", "Dust, Pollen & Food Allergies", "Chronic Sinusitis & Headache", "Bronchitis & Chest Congestion"],
        hi: ["एलर्जिक राइनाइटिस (बार-बार छींके आना)", "दमा व सांस फूलना (Asthma)", "धूल, मौसम व धुएं से एलर्जी", "क्रोनिक साइनोसाइटिस व सिरदर्द", "पुरानी ब्रोंकाइटिस व कफ की जकड़न"]
      },
      note: {
        en: "Aims to desensitize your immune system so you do not react severely to weather and dust changes.",
        hi: "शरीर की आंतरिक रोग प्रतिरोधक प्रणाली को मजबूत कर एलर्जी को शांत करता है।"
      }
    },
    {
      id: "ent-care",
      category: "general",
      icon: "volume-2",
      title: {
        en: "Ear, Nose & Throat (ENT)",
        hi: "कान, नाक एवं गले के रोग"
      },
      tagline: {
        en: "Effective non-surgical solutions for recurrent throat and sinus problems",
        hi: "गले में खराश, टॉन्सिल और नाक की समस्याओं का सरल समाधान"
      },
      conditions: {
        en: ["Recurrent Tonsillitis", "Nasal Polyps & Blocked Nose", "Sinus Congestion & Pain", "Ear Infections & Discharge", "Chronic Sore Throat & Hoarseness"],
        hi: ["बार-बार टॉन्सिल पकना", "नाक की हड्डी या मांस बढ़ना (Polyp)", "साइनस का दर्द व भारीपन", "कान में दर्द व मवाद आना", "गले में खराश व आवाज बैठना"]
      },
      note: {
        en: "Many patients with recurring tonsils or polyps experience marked improvement under individualised care.",
        hi: "टॉन्सिल व नेजल पॉलिप में कई मरीजों को बिना ऑपरेशन उल्लेखनीय सुधार मिलता है।"
      }
    },
    {
      id: "kidney-urinary",
      category: "chronic",
      icon: "droplet",
      title: {
        en: "Kidney & Urinary Tract Care",
        hi: "किडनी एवं मूत्र संबंधी समस्याएं"
      },
      tagline: {
        en: "Natural renal wellness, stone management, and UTI comfort",
        hi: "किडनी पथरी व बार-बार पेशाब के संक्रमण का सुरक्षित उपचार"
      },
      conditions: {
        en: ["Renal Calculi (Kidney Stones Management)", "Recurrent Urinary Tract Infections (UTI)", "Burning Micturition & Bladder Discomfort", "Prostate Enlargement Support (BPH)", "Renal Supportive Care"],
        hi: ["गुर्दे की पथरी (Kidney Stone)", "बार-बार पेशाब का संक्रमण (UTI)", "पेशाब में जलन व दर्द", "प्रोस्टेट ग्रंथि का बढ़ना (BPH)", "किडनी स्वास्थ्य सहायक प्रबंधन"]
      },
      note: {
        en: "Helps ease stone-related spasms and clears recurrent urinary burning naturally.",
        hi: "पथरी के दर्द से राहत तथा बार-बार पथरी बनने की प्रवृत्ति को रोकने में सहायक।"
      }
    },
    {
      id: "mental-wellness",
      category: "chronic",
      icon: "moon",
      title: {
        en: "Mental Wellness & Stress Care",
        hi: "मानसिक स्वास्थ्य एवं तनाव प्रबंधन"
      },
      tagline: {
        en: "Non-habit forming, calming holistic remedies for inner peace",
        hi: "बिना किसी आदत या सुस्ती के मन को शांत व स्थिर करने में सहायक"
      },
      conditions: {
        en: ["Anxiety & Nervous Tension", "Mild to Moderate Depression Support", "Insomnia & Restless Sleep", "Chronic Stress & Burnout", "Exam Panic & Phobias"],
        hi: ["घबराहट व बेचैनी (Anxiety)", "उदास मन व निराशा", "नींद न आना (Insomnia)", "मानसिक तनाव व सिरदर्द", "परीक्षा का डर व आत्मविश्वास की कमी"]
      },
      note: {
        en: "100% non-sedative and non-habit forming. Works harmoniously with your emotional and mental state.",
        hi: "इन दवाओं की कोई लत नहीं पड़ती और न ही दिन में सुस्ती आती है।"
      }
    },
    {
      id: "general-care",
      category: "general",
      icon: "plus-circle",
      title: {
        en: "General & Seasonal Ailments",
        hi: "सामान्य एवं मौसमी बीमारियां"
      },
      tagline: {
        en: "Fast, safe relief for acute daily health issues",
        hi: "दैनिक स्वास्थ्य समस्याओं व मौसमी बुखार आदि में त्वरित राहत"
      },
      conditions: {
        en: ["Viral Fevers & Bodyache", "Typhoid Supportive Recovery", "Jaundice & Liver Convalescence", "General Physical Weakness", "Headaches & Migraines", "Digestive Colic & Vomiting"],
        hi: ["मौसमी बुखार, सर्दी व बदन दर्द", "टाइफाइड के बाद की कमजोरी", "पीलिया में लिवर की रिकवरी", "शारीरिक दुर्बलता व खून की कमी", "माइग्रेन व सिरदर्द", "उल्टी व पेट दर्द"]
      },
      note: {
        en: "Gentle remedies that help the body bounce back faster from acute seasonal infections.",
        hi: "कमजोरी को दूर कर जल्दी स्वस्थ होने में मदद करता है।"
      }
    }
  ],

  whyHomoeopathy: [
    {
      icon: "leaf",
      title: {
        en: "No Harmful Side Effects",
        hi: "हानिरहित एवं दुष्प्रभावमुक्त"
      },
      desc: {
        en: "Prepared through microscopic micro-dilutions, homoeopathic medicines are gentle on the stomach, kidneys, and liver, causing no chemical toxicity.",
        hi: "अत्यंत सूक्ष्म एवं शुद्ध मात्रा में तैयार की जाने वाली ये औषधियां पेट, लिवर व गुर्दे पर कोई हानिकारक प्रभाव नहीं डालतीं।"
      }
    },
    {
      icon: "users",
      title: {
        en: "Safe for Children & Elders",
        hi: "बच्चों से बुजुर्गों तक सुरक्षित"
      },
      desc: {
        en: "The sweet pills are easy and pleasant for infants and children to take, and gentle enough for elderly patients managing multiple ailments.",
        hi: "मीठी गोलियां बच्चे बिना किसी नखरे के आसानी से खा लेते हैं तथा बुजुर्गों के लिए भी अत्यंत सुपाच्य और सुरक्षित हैं।"
      }
    },
    {
      icon: "compass",
      title: {
        en: "Treats the Person, Not Just Symptoms",
        hi: "रोग की जड़ और संपूर्ण व्यक्तित्व का उपचार"
      },
      desc: {
        en: "Rather than masking pain or skin eruptions temporarily, homoeopathy identifies your unique constitutional makeup to correct the underlying disbalance.",
        hi: "लक्षणों को केवल दबाने के बजाय व्यक्ति की मानसिक व शारीरिक प्रकृति समझकर रोग के मूल कारण का निवारण किया जाता है।"
      }
    },
    {
      icon: "shield-check",
      title: {
        en: "Relief in Recurring & Chronic Complaints",
        hi: "बार-बार होने वाले रोगों में स्थायी लाभ"
      },
      desc: {
        en: "Particularly beneficial for stubborn chronic issues like allergies, skin rashes, joint stiffness, and hormonal imbalances that recur seasonally.",
        hi: "एलर्जी, त्वचा रोग, गठिया और माहवारी की समस्याओं जैसे बार-बार लौटने वाले पुराने रोगों में दीर्घकालिक लाभ देता है।"
      }
    },
    {
      icon: "zap",
      title: {
        en: "Builds Natural Immunity",
        hi: "प्राकृतिक रोग प्रतिरोधक क्षमता में वृद्धि"
      },
      desc: {
        en: "Constitutional remedies stimulate the body's natural defensive vitality, helping prevent future illnesses and speeding natural recovery.",
        hi: "दवाइयां शरीर की अपनी आत्म-रक्षा प्रणाली को सक्रिय करती हैं, जिससे बार-बार बीमार पड़ने की प्रवृत्ति कम होती है।"
      }
    }
  ],

  reviews: [
    {
      id: 1,
      name: {
        en: "Patient Review (Add your Google review here)",
        hi: "मरीज का अनुभव (गूगल रिव्यू आधारित)"
      },
      location: {
        en: "Vijay Nagar, Jabalpur",
        hi: "विजय नगर, जबलपुर"
      },
      condition: {
        en: "Chronic Skin & Allergy Treatment",
        hi: "पुरानी त्वचा एलर्जी एवं खाज-खुजली"
      },
      quote: {
        en: "“Dr. Pankaj Nema is very understanding and listens to the entire problem with immense patience. I had been troubled with recurring skin issues for 2 years. After starting treatment here, my skin cleared up naturally without heavy ointments. Truly grateful!”",
        hi: "“डॉ. पंकज नेमा बहुत ही समझदार और धैर्यवान डॉक्टर हैं। वे पूरी समस्या को बहुत ध्यान से सुनते हैं। मुझे 2 साल से स्किन एलर्जी थी, यहां इलाज लेने के बाद बिना किसी तेज दवाओं के बहुत आराम मिला।”"
      },
      rating: 5,
      themeTag: {
        en: "Patient Listening & Understanding",
        hi: "धैर्यपूर्वक सुनना व समझना"
      }
    },
    {
      id: 2,
      name: {
        en: "Family Consultation (Verified Google Feedback)",
        hi: "पारिवारिक परामर्श (सत्यापित गूगल फीडबैक)"
      },
      location: {
        en: "Jabalpur",
        hi: "जबलपुर"
      },
      condition: {
        en: "Child Recurrent Cold & Weak Immunity",
        hi: "बच्चे को बार-बार सर्दी-जुकाम एवं कमजोरी"
      },
      quote: {
        en: "“The friendly atmosphere and doctor's polite nature make visiting the clinic a stress-free experience. My 4-year-old child had recurrent cough every month. Homoeopathic sweet pills worked wonders for her immunity. Highly recommended for families.”",
        hi: "“क्लीनिक का शांत और दोस्ताना वातावरण बहुत अच्छा है। मेरी 4 साल की बेटी को हर महीने सर्दी-खांसी हो जाती थी। डॉ. नेमा की मीठी दवाइयों से उसकी इम्यूनिटी बहुत सुधर गई है। परिवार के लिए सबसे भरोसेमंद क्लीनिक।”"
      },
      rating: 5,
      themeTag: {
        en: "Friendly Atmosphere & Child Care",
        hi: "शांत माहौल एवं बाल स्वास्थ्य"
      }
    },
    {
      id: 3,
      name: {
        en: "Patient Review (Add your Google review here)",
        hi: "मरीज का अनुभव (गूगल रिव्यू आधारित)"
      },
      location: {
        en: "Madhya Pradesh",
        hi: "मध्य प्रदेश"
      },
      condition: {
        en: "Severe Joint Pain & Acidity",
        hi: "जोड़ों का दर्द एवं एसिडिटी"
      },
      quote: {
        en: "“Dr. Nema explains the root cause clearly and gives realistic, honest advice without exaggerated promises. The knee pain and long-standing acidity have reduced significantly over the last 3 months. Genuine doctor who cares for patients.”",
        hi: "“डॉक्टर साहब बीमारी का सही कारण समझाते हैं और कोई झूठा दावा नहीं करते। मुझे घुटने के दर्द और पुरानी एसिडिटी में काफी राहत मिली है। जबलपुर में एक सच्चे और अनुभवी होम्योपैथ।”"
      },
      rating: 5,
      themeTag: {
        en: "Honest Guidance & Joint Relief",
        hi: "ईमानदार सलाह व दर्द से राहत"
      }
    }
  ],

  gallery: [
    {
      type: "photo",
      src: "assets/images/doctor-consultation.jpg",
      title: {
        en: "Doctor Consultation Chamber",
        hi: "डॉक्टर परामर्श कक्ष"
      },
      subtitle: {
        en: "Dr. Pankaj Nema at the clinic consultation desk",
        hi: "डॉ. पंकज नेमा परामर्श कक्ष में"
      }
    },
    {
      type: "photo",
      src: "assets/images/clinic-front.jpg",
      title: {
        en: "Clinic Entrance & Signboard",
        hi: "क्लीनिक प्रवेश द्वार व मुख्य बोर्ड"
      },
      subtitle: {
        en: "D-2, SBI Chowk, Vijay Nagar Road, Jabalpur",
        hi: "डी-2, एसबीआई चौक, विजय नगर रोड, जबलपुर"
      }
    },
    {
      type: "photo",
      src: "assets/images/clinic-inside.jpg",
      title: {
        en: "Consultation & Reception Desk",
        hi: "परामर्श कक्ष एवं स्वागत पटल"
      },
      subtitle: {
        en: "Peaceful, hygienic environment for thorough case taking",
        hi: "मरीज की विस्तृत बातचीत हेतु शांत व स्वच्छ वातावरण"
      }
    },
    {
      type: "poster",
      src: "assets/images/posters/joint-pain-treatment.jpg",
      title: {
        en: "Joint Pain & Sciatica Treatment",
        hi: "जोड़ों का दर्द एवं साइटिका उपचार"
      },
      subtitle: {
        en: "Knee pain, cervical, spondylitis and arthritis care",
        hi: "घुटनों का दर्द, गठिया एवं रीढ़ की हड्डी संबंधी परामर्श"
      }
    },
    {
      type: "poster",
      src: "assets/images/posters/womens-wellness.jpg",
      title: {
        en: "Women's Wellness & Hormonal Health",
        hi: "महिला स्वास्थ्य एवं हार्मोनल समस्याएं"
      },
      subtitle: {
        en: "PCOD, irregular periods, thyroid & natural fertility support",
        hi: "पीसीओडी, माहवारी कष्ट, थायराइड व निःसंतानता परामर्श"
      }
    },
    {
      type: "poster",
      src: "assets/images/posters/skin-care-treatment.jpg",
      title: {
        en: "Skin & Hair Comprehensive Care",
        hi: "त्वचा एवं बाल रोग विशेष चिकित्सा"
      },
      subtitle: {
        en: "Acne, blemishes, eczema, psoriasis & hair fall solutions",
        hi: "कील-मुंहासे, झाइयां, दाद-खाज व बाल झड़ने का समाधान"
      }
    },
    {
      type: "poster",
      src: "assets/images/posters/autism-child-health.jpg",
      title: {
        en: "Child Developmental & Autism Support",
        hi: "शिशु विकास एवं ऑटिज़्म सहायता"
      },
      subtitle: {
        en: "Speech delay, hyperactivity & constitutional child care",
        hi: "बोलने में देरी, हाइपरएक्टिविटी एवं बाल स्वास्थ्य परामर्श"
      }
    },
    {
      type: "poster",
      src: "assets/images/posters/kidney-care.jpg",
      title: {
        en: "Kidney Health & Stone Management",
        hi: "गुर्दे का स्वास्थ्य एवं पथरी प्रबंधन"
      },
      subtitle: {
        en: "Renal calculi, recurrent UTI & urinary burning relief",
        hi: "किडनी स्टोन, यूटीआई व पेशाब में जलन की समस्या"
      }
    },
    {
      type: "poster",
      src: "assets/images/posters/thyroid-care.jpg",
      title: {
        en: "Thyroid Functioning & Metabolic Care",
        hi: "थायराइड एवं मेटाबॉलिज्म देखभाल"
      },
      subtitle: {
        en: "Hypo & hyperthyroidism supportive natural homoeopathy",
        hi: "थायराइड असंतुलन में सुरक्षित होम्योपैथिक सहायता"
      }
    }
  ],

  videos: [
    {
      id: "consultation-video",
      src: "assets/videos/doctor-patient-consultation.mp4",
      poster: "assets/images/video-poster-2.jpg",
      duration: "0:17",
      tag: {
        en: "Doctor in Consultation",
        hi: "डॉ. पंकज नेमा परामर्श"
      },
      title: {
        en: "Patient Examination & Holistic Consultation",
        hi: "डॉ. पंकज नेमा द्वारा मरीज जांच व धैर्यपूर्ण परामर्श"
      },
      description: {
        en: "Dr. Pankaj Nema conducting a thorough physical evaluation for a patient presenting with knee and musculoskeletal pain, demonstrating our clinic's warm, patient-first care.",
        hi: "जोड़ों के दर्द से पीड़ित मरीज की स्थिति का व्यक्तिगत परीक्षण करते हुए डॉ. पंकज नेमा। प्रत्येक मरीज को पूरा समय देकर संपूर्ण शारीरिक स्थिति की जांच की जाती है।"
      }
    },
    {
      id: "signboard-video",
      src: "assets/videos/clinic-signboard-tour.mp4",
      poster: "assets/images/video-poster-1.jpg",
      duration: "0:19",
      tag: {
        en: "Clinic Entrance & Signboard",
        hi: "क्लीनिक मुख्य द्वार व साइनबोर्ड"
      },
      title: {
        en: "Clinic Entrance & Signboard at Night",
        hi: "नेमा होम्योपैथिक क्लीनिक - मुख्य साइनबोर्ड एवं प्रवेश द्वार"
      },
      description: {
        en: "Evening view of Nema Homoeopathic Clinic near Hanuman Temple, SBI Chowk, Vijay Nagar Road, Jabalpur — well-illuminated and easily accessible for visiting patients.",
        hi: "हनुमान मंदिर के पास, एसबीआई चौक, विजय नगर रोड जबलपुर पर क्लीनिक का रात्रि दृश्य एवं साइनबोर्ड। मुख्य मार्ग पर स्थित होने से पहुंचना अत्यंत सुगम।"
      }
    },
    {
      id: "overview-video",
      src: "assets/videos/clinic-appointment-overview.mp4",
      poster: "assets/images/video-poster-3.jpg",
      duration: "0:18",
      tag: {
        en: "Dispensary & Contact",
        hi: "दवा वितरण व समय"
      },
      title: {
        en: "Dispensary Hours & Online Consultation Info",
        hi: "क्लीनिक परामर्श समय, दवा वितरण एवं ऑनलाइन संपर्क"
      },
      description: {
        en: "Clear overview of clinic shifts (11:00 AM–2:00 PM & 6:00 PM–9:00 PM), verified consultation contact numbers, and online appointment booking access.",
        hi: "सुबह 11 से 2 व शाम 6 से 9 बजे का क्लीनिक समय, प्रामाणिक दवा वितरण सुविधा और ऑनलाइन परामर्श हेतु संपर्क विवरण।"
      }
    }
  ]
};

// Expose to window
if (typeof window !== "undefined") {
  window.CLINIC_DATA = CLINIC_DATA;
}
